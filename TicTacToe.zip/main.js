let options = document.querySelectorAll('.box')
let playerTurnIndex = 0

// function whoWonDiagonal() {
//   let diag = 1

//   for (var j = 0; j < options.length; j += 3) {

//   }
// }

function whoWonHorizontal() {
  let row = 1   //  This is my first row to check if they are equals
  
  for (var j = 0; j < options.length; j += 3) {
    if (options[j].textContent != '') {
      if (options[j].textContent == options[row].textContent && options[j].textContent == options[row+1].textContent) {
        if (options[j].textContent == 'X') {
          alert('X PLAYER WINS!!!')
          break
        } else {
          alert('O PLAYER WINS!!!')
          break
        }
      }
    }
    row += 3
  }
}

function playerTurn(event) {
  const targetPosition = event.target
  for (var j = 0; j < options.length; j++) {
    if (playerTurnIndex % 2 == 0) {
      if (targetPosition.textContent === '') {
        targetPosition.textContent = 'X'
        playerTurnIndex++
        whoWonHorizontal()
        // whoWonDiagonal()
        break
      } else {
        alert("You need to pick an empty block")
        break
      }
    } else {
      if (targetPosition.textContent === '') {
        targetPosition.textContent = 'O'
        playerTurnIndex++
        whoWonHorizontal()
        // whoWonDiagonal()
        break
      } else {
        alert("You need to pick an empty block")
        break
      }
    }

  }
}

for (var i = 0; i < options.length; i++) {
  const playerChoice = options[i]
  playerChoice.addEventListener('click', playerTurn)
}